fx_version 'bodacious'
author 'Brown Development'
description 'Browns Peer Sync Example Script'
game 'gta5'
lua54 'yes'

shared_script '@ox_lib/init.lua'

client_script 'main.lua'
server_script 'server.lua'

files {
    'modules/browns_peerSync/*.lua'
}

dependency 'ox_lib'