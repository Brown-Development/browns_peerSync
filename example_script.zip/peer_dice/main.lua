local peer = require 'modules.browns_peerSync.client' -- loading the module

peer.new() -- registering the client as a peer 

local name = peer.client.name -- our peer name (steam name, etc)

local function joinDiceGame() -- function to join the dice game and start listening for communications

    if not peer.getdata('dicegame') then  -- check to see if the dicegame has a host yet if not then we create a new key called 'dicegame' and sync it to all peers and register ourselves as the game host
        peer.setdata('dicegame', {})
        peer.setdata('dicegame.host', peer.client.id)
    end

    peer.channel.add('dice') -- add the client to the 'dice' channel so they can sync with the other players in the dice game

    peer.on('joined_dice', function(player) -- listen for when a player joins dice game and trigger a chat message
        exports.chat:addMessage({
            color = {255, 0, 0},
            args = {"Dice Game", string.format('%s has joined dice game!', player)}
        })
    end)

    peer.on('dice_roll', function(player, roll) -- listen for when a player rolls a dice doing and trigger a chat message
        exports.chat:addMessage({
            color = {255, 0, 0},
            args = {"Dice Game", string.format('%s has rolled a %d', player, roll)}
        })
    end)

    peer.on('dicegame_started', function() -- listen for when the dice game is started by the dice game host and trigger a chat message
        exports.chat:addMessage({
            color = {255, 0, 0},
            args = {"Dice Game", 'dice game started, first to roll a number higher than 10 gets a point!'}
        })
    end)

    peer.on('dice_win', function(player) -- listen for when someone wins a dice game and trigger a chat message
        exports.chat:addMessage({
            color = {255, 0, 0},
            args = {"Dice Game", string.format('%s has won the dice game!', player)}
        })
    end)

    peer.net('joined_dice', { 'dice' }, name) -- tell all players that we have joined
end


--- COMMANDS ---


RegisterCommand('playdice', function() -- command to join the dice game
    joinDiceGame()
end)

RegisterCommand('startdice', function() -- command to start the dice game
    local host = peer.getdata('dicegame.host')

    if host ~= peer.client.id then return end  -- make sure that you are the host of the dice game before you make the executive decision to start the dice game

    peer.setdata('dicegame.started', true) -- let all peers know the dice game has started, allowing them to roll dice doing /roll command

    peer.net('dicegame_started', { 'dice' })
end)

RegisterCommand('roll', function() -- command to roll a dice
    local started = peer.getdata('dicegame.started') 

    if not started then return end -- making sure the dice game has started which is started by the host client when theyu do /startdice before we continue our roll

    local roll = math.random(2, 12)

    peer.net('dice_roll', { -- telling the peers in the dice channel that we rolled (makes them trigger a chat message)
        'dice'
    }, name, roll)

    if roll > 10 then 
        peer.net('dice_win', { 'dice' },  name) -- if our roll is higher then 10 then we win and we let all other peers know


        local wins = peer.getdata('dicegame.wins') -- checking to see if any player has won yet by seeing if the dicegame.wins table exists in the peer synced data

        if not wins then -- if there are no whens they we take it upon ourselves to make the dicegame.wins table and sync it between all the peers 
            peer.setdata('dicegame.wins', {}) 

            wins = peer.getdata('dicegame.wins')
        end

        local myscore = wins[peer.client.name] -- check to see if we have our name registered on the scoreboard

        if not myscore then  -- if we dont have our name registered on the scoreboard then we register ourselves and add our first point
            wins[peer.client.name] = 1
            peer.setdata('dicegame.wins', wins)
            return 
        end
        
        wins[peer.client.name] = wins[peer.client.name] + 1 -- if we are already on the scoreboard indicating we previously won then we update our score + 1

        peer.setdata('dicegame.wins', wins) -- sync our score data with call peers

    end
end)

RegisterCommand('dicescore', function() -- getting the scoreboard showing all peers scores
    local scores = peer.getdata('dicegame.wins') 

    if not scores then return end  -- checking to see if the scoreboard even exists before looking at it

    for k in pairs(scores) do -- for each score in the scoreboard we send a chat message to ourselves showing the peers name and their score
        exports.chat:addMessage({
            color = {255, 0, 0},
            args = {"Dice Game", string.format('%s: %d Points', k, scores[k])}
        })
    end
end)