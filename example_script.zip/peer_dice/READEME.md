This an example script on how you can use Browns Peer Sync

This script makes a chat based dice game

how it works:

1. Players Join dice game by ding /playdice

2. The first player to join becomes the host and only the host can start the game by doing /startdice

3. once the game is started players can do /roll over and over giving them a random number

4. if a player lands on a number greater than 10 then they win and get a point

5. you can see all points (scoreboard) by doing /dicescore which will show the players name and their score

Overall this is a prime example on how you can use client side only code to sync data between
clients, usually sharing the information (scores, chat messages, etc.) are done through
client - server - client but with the module you can do it all client side and all the data
is shared and synced instantly

the only thing you need to do on server side is initiate the module server sided which you will see in
server.lua

**This Example Script REQUIRES ox_lib**

discord @bwobrown
discord server: https://discord.gg/vXP2ekDT3j