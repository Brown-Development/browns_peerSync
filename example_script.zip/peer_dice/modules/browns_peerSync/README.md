# Browns Peer Sync by Brown Development

Personal Discord: @bwobrown
Discord Server: https://discord.gg/vXP2ekDT3j

# About 
Browns Peer Sync is a Lua Module for FiveM that provides a more easier, faster, & optimized way of client to client syncing & communication.

# Documentation
https://brown-development.gitbook.io/browns_peersync